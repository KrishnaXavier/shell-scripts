#!/bin/bash
source  manager

interface